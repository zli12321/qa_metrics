import requests
import os

def bem():
    return None